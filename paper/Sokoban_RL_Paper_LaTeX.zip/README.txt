Compile with pdfLaTeX and BibTeX:

pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex

The archive contains all figure files and the bibliography.
For Overleaf, upload the ZIP as a project and select main.tex as the main document.
No institution-specific conference template or external images are required.
